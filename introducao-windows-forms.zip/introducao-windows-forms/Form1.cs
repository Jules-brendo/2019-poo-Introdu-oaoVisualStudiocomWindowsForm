﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace introducao_windows_forms
{
    public partial class k : Form
    {
        private Conta c;

        public k()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.c = new Conta();
            c.Numero = 1;
            c.Deposita(500);
            c.Titular = new Cliente("Victor");

            //textoTitular.Text = c.Titular.Nome;
            //textoNumero.Text = Convert.ToString(c.Numero);
            //textoSaldo.Text = Convert.ToString(c.Saldo);

            //
            this.MostrarConta();
        }

        private void TextoTitular_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string valorDigitado = textoValor.Text;
            double valorOperacao = Convert.ToDouble(valorDigitado);
            this.c.Deposita(valorOperacao);

            textoSaldo.Text = Convert.ToString(this.c.Saldo);
            //MessageBox.Show("Sucesso");

            //textoNumero.Text = Convert.ToString(this.c.Numero);
            //textoSaldo.Text = Convert.ToString(this.c.Saldo);
            //textoTitular.Text = this.c.Titular.Nome;

            this.MostrarConta();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string valorDigitado = textoValor.Text;
            double valorOperacao = Convert.ToDouble(valorDigitado);
            this.c.Saca(valorOperacao);
            textoSaldo.Text = Convert.ToString(this.c.Saldo);
            //MessageBox.Show("Sucesso");

            this.MostrarConta();

        }
        private void MostrarConta()
        {
            textoNumero.Text = Convert.ToString(this.c.Numero);
            textoSaldo.Text = Convert.ToString(this.c.Saldo);
            textoTitular.Text = this.c.Titular.Nome;
        }
        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void TextoValor_TextChanged(object sender, EventArgs e)
        {

        }
        // Captulo 9 topico 10 Questão Opcional 1 
        // R: Compila e faz com que a variável conta seja do tipo Conta.
        //var conta = new Conta();
        //conta.Titular = new Cliente();

        // Captulo 9 topico 10 Questão Opcional 2
        // R: A linha 3 não compila pois o tipo de uma variável não pode ser trocado e ele é inferido ao declarar a variável.
        //var simples = new Conta(); // linha 1
        //simples = new Conta(); // linha 2
        //simples = new Cliente(); // linha 3

        // Captulo 9 topico 10 Questão Opcional 3
        //R : O código não compila pois, ao declarar uma variável como var, é obrigatório definir um valor inicial a ela logo na declaração para que o compilador consiga inferir qual o tipo que será utilizado.
        //var conta;
        //conta = new conta();
        //conta.deposita(300);

        // Captulo 9 topico 10 Questão Opcional 4
        //R: O código compila e roda imprimindo 2.
        //var tamanho = 5;
        //tamanho = tamanho / 2.0;
        //MessageBox.Show(tamanho);

    }
}
