﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace introducao_windows_forms
{
    class Conta
    {
        public int Numero { get; set; }
        public double Saldo { get; private set; }
        public Cliente Titular { get; set; }
        public Conta(string titular)
        {

        }
        public Conta()
        {

        }

        internal void Deposita(double valorOperacao)
        {
            this.Saldo += valorOperacao;
        }
        public void Saca(double valor)
        {
            this.Saldo -= valor;
        }
    }
}
